<?php

define('DB_USER', "id9004268_thuthapdulieu");     // Your database user name
define('DB_PASSWORD', "smartdatalogger");			// Your database password (mention your db password here)
define('DB_DATABASE', "id9004268_thuthapdulieu"); // Your database name
define('DB_SERVER', "localhost");			// db server (Mostly will be 'local' host)

?>
