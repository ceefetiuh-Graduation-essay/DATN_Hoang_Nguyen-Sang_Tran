<?php
//Creates new record as per request
    $servername = "localhost";
    $username = "id9224847_ngochoang";
    $password = "01654755979";
    $dbname = "id9224847_data";

    // Create connection
    $conn = mysqli_connect($servername, $username, $password, $dbname);
    // Check connection
    if ($conn->connect_error) {
        //die("Database Connection failed: " . $conn->connect_error);
    }
    else {
        //echo "Đã kết nối mysqli";
    }

    $sql="SELECT * FROM `slave1_maxmin` ORDER BY `messageID` DESC LIMIT 0,1";

    $result = mysqli_query($conn, $sql);
	//nếu có hàng dữ liệu trong bảng
	if(!empty($_POST['load'])){
	    if (mysqli_num_rows($result) > 0) 
		{
			// output dữ liệu trên trang
			while($row = mysqli_fetch_assoc($result)) 
			{
				//echo "OK";
				print_r("min1a");//in ra theo hàng c
				print_r($row['min_temp']);//in ra theo hàng c
				
				print_r($row['min_hum']);//in ra theo hàng h
				
				print_r($row['min_soil']);//in ra theo hàng s


				print_r("max1a");//in ra theo hàng c
				print_r($row['max_temp']);//in ra theo hàng c

				print_r($row['max_hum']);//in ra theo hàng h

				print_r($row['max_soil']);//in ra theo hàng s
			}
		} 
		else 
		{
			//echo "0 results";
		}
	 }




   	$conn->close();
   ?>
