<?php
//Creates new record as per request
    $servername = "localhost";
    $username = "id9224847_ngochoang";
    $password = "01654755979";
    $dbname = "id9224847_data";


    // Create connection
    $conn = mysqli_connect($servername, $username, $password, $dbname);
    // Check connection
    if ($conn->connect_error) {
        die("Database Connection failed: " . $conn->connect_error);
    }
    else {
        echo "Đã kết nối mysqli";
    }


    //Get current date and time

      if(isset($_POST['C']) && isset($_POST['H'])&& isset($_POST['S'])&& isset($_POST['M']))
       {
       	$nhiet_do = $_POST['C'];
       	$do_am = $_POST['H'];
        $am_dat=$_POST['S'];
        $motor=$_POST['M'];

   	    $sql = "INSERT INTO tbl_messages3(nhiet_do, do_am,am_dat,motor) VALUES ('".$nhiet_do."', '".$do_am."','".$am_dat."','".$motor."')";

   		if ($conn->query($sql) === TRUE) {
   		    echo "Gửi dữ liệu thành công";
   		} else {
   		    echo "Error: " . $sql . "<br>" . $conn->error;
   		}
   	}



   	$conn->close();
   ?>
