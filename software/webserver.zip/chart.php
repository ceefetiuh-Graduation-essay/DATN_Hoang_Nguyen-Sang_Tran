<?php
 $con=mysqli_connect('localhost','id9224847_ngochoang','01654755979','id9224847_data');
 $row='';
 $query="SELECT*FROM tbl_messages ORDER BY DateTime_created DESC LIMIT 0,30";
 $result=mysqli_query($con,$query);
 ?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
      <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Chart</title>
	<!-- Bootstrap Styles-->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
     <!-- FontAwesome Styles-->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
     <!-- Morris Chart Styles-->
    <link href="assets/js/morris/morris-0.4.3.min.css" rel="stylesheet" />
        <!-- Custom Styles-->
    <link href="assets/css/custom-styles.css" rel="stylesheet" />
     <!-- Google Fonts-->
   <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
   <link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/morris.js/0.5.1/morris.css">
    <script src="//ajax.googleapis.com/ajax/libs/jquery/1.9.0/jquery.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/raphael/2.1.0/raphael-min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/morris.js/0.5.1/morris.min.js"></script>
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <style>img[alt="www.000webhost.com"]{display:none;}</style>
</head>
<body>
    <div id="wrapper">
        <nav class="navbar navbar-default top-navbar" role="navigation">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.html"><i class="fa fa-cloud-upload" style="font-size:24px;margin-left:55px;"></i><strong>  HOME </strong></a>
            </div>

            <ul class="nav navbar-top-links navbar-right">

                <!-- /.dropdown -->
                <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#" aria-expanded="false">
                        <i class="fa fa-user fa-fw"></i> <i class="fa fa-caret-down"></i>
                    </a>
                    <ul class="dropdown-menu dropdown-user">
                        <li><a href="#"><i class="fa fa-user fa-fw"></i> Xin chào Admin</a>
                        </li>
                        <li class="divider"></li>
                        <li><a href="logout.php"><i class="fa fa-sign-out fa-fw"></i>Đăng xuất</a>
                        </li>
                    </ul>
                    <!-- /.dropdown-user -->
                </li>
                <!-- /.dropdown -->
            </ul>
        </nav>
        <!--/. NAV TOP  -->
        <nav class="navbar-default navbar-side" role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav" id="main-menu">
                  <li>
                      <a href="#" class="active-menu"><i class="fa fa-bar-chart-o"></i> DEVICE ONE CHART</a>
                  </li>
                  <li>
                        <a href="chart2.php"><i class="fa fa-bar-chart-o"></i> DEVICE TWO CHART</a>
                  </li>
                  <li>
                        <a href="hienthi.php"><i class="fa fa-dashboard"></i> DEVICE ONE</a>
                  </li>

                  <li>
                        <a href="hienthi_2.php"><i class="fa fa-dashboard"></i> DEVICE TWO</a>
                  </li>
                  <li>
                      <a href="table.php"><i class="fa fa-table"></i> DEVICE ONE TABLE </a>
                  </li>
                  <li>
                      <a href="table2.php"><i class="fa fa-table"></i> DEVICE TWO TABLE</a>
                  </li>



                </ul>

            </div>

        </nav>

<!----------------------------------------------------------------------------->
<div id="page-wrapper" >
    <div id="page-inner">
			 <div class="row">
          <div class="col-md-12">
              <h1 class="page-header">
                  Charts <small>Show up your stats</small>
              </h1>
          </div>
      </div>
<!---------------------------------------------------------------------------->
      <div class="row">
        <div class="col-md-6 col-sm-12 col-xs-12">
          <div class="panel panel-default" style="width:1000px;height:600px;">
              <div class="panel-heading">Temperture & Humidity & Soil</div>
              <div class="panel-body">
                <div id="chart" style="width:970px;height:500px;"></div>
              </div>
          </div>
        </div>
    </div>
<!----------------------------------------------------------------------------->
<!----------------------------------------------------------------------------->

			</div>

    </div>
</div>
<!----------------------------------------------------------------------------->
    <script src="assets/js/jquery-1.10.2.js"></script>
      <!-- Bootstrap Js -->
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- Metis Menu Js -->
    <script src="assets/js/jquery.metisMenu.js"></script>
<!--Chart---------------------------------------------------------------------->
    <script type="text/javascript">
          google.charts.load('current', {'packages':['corechart']});
          google.charts.setOnLoadCallback(drawChart);

          function drawChart() {
            var data = google.visualization.arrayToDataTable([

                            ['Time', 'Temperture','Humidity','Soil'],
                            <?php
                            while($row = mysqli_fetch_array($result))
                            {
                                 echo "['".$row["DateTime_created"]."', ".$row["nhiet_do"].", ".$row["do_am"].", ".$row["am_dat"]."],";
                            }
                            ?>
                       ]);

            var options = {
              title: 'Information',
              curveType: 'function',
              legend: { position: 'bottom' }
            };

            var chart = new google.visualization.LineChart(document.getElementById('chart'));

            chart.draw(data, options);
          }
        </script>

</body>
</html>
