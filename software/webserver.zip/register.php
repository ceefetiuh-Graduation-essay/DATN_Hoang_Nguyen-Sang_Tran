
<!DOCTYPE html>
<html>
<head>
	<title>Register</title>
<!--Add thẻ thư viện CSS------------------------------------------------------->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
<!--Add thẻ thư viện icon------------------------------------------------------>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<style>img[alt="www.000webhost.com"]{display:none;}</style>

<style>
*{
	margin: 0px;
	padding:0px;
}
body{
	font-size: 120%;
	background:#8cd9b3;
	height: 700px;
}
</style>

<!----------------------------------------------------------------------------->
</head>
<body>

<div class="container">
	<div class="row text-center">
<!--Add Logo -->
	<a href="index.html">
		<img src="images/MAU2.png" style="width:300px;height:300px">
	</a>

	</div>
<!--XỬ LÍ REGISTER------------------------------------------------------------->
  <div class="row">
		<?php require('config.php'); ?>
    <div class="col-md-6 col-md-offset-3 text-center thongbaoloi">
      <?php
        if(isset($_POST['submit'])){
          if(empty($_POST['username']) or empty($_POST['password'] or empty($_POST['email'])) ){
            echo '<p style="color:red"> Vui lòng không để trống</p>';
          }
          else {

            $username=$_POST['username'];
            $email=$_POST['email'];
            $password=$_POST['password'];
            $password2=$_POST['password2'];

/*----------------------------Hàm xử lí PHP-----------------------------------*/
          if(strlen($username)< 6 or strlen($password)< 6){
              echo '<p style="color:red">Username và password phải nhiều hơn 6 kí tự</p>';
          }
          else {

            if($password2!=$password)
            {
              echo '<p style="color:red">Password không trùng nhau</p';
            }
            else{
              $sql="select * from users where username='$username'and email='$email'";
              $query=mysqli_query($con,$sql);
              $num=mysqli_num_rows($query);
              if($num==0)
							{
                $sql2="INSERT INTO users(username,password,email) VALUES('$username','$password','$email')";
                $them=mysqli_query($con,$sql2);
                if($them)
                {
                  echo '<p style="color:#05824">Đăng kí thành công .Vui lòng đăng nhập</p';
                }
                else {
                  echo '<p style="color:red">Đăng kí không thành công </p';
                }
              }
              else
              {
                echo '<p style="color:red">Tên đã tồn tại</p';
              }
            }
          }
       }
    }
?>

    </div>
</div>
<!--THẺ TẠO BẢNG--------------------------------------------------------------->
  <div class="row">
    <div class="col-md-6 col-md-offset-3">
      <form class="" action="" method="POST" role="form">
        <div class="form-group">
          <label for="">Username</label>
          <input type="text" name="username" class="form-control" id="placeholder">
        </div>
        <div class="form-group">
          <label for="">Email</label>
          <input type="email" name="email" class="form-control" id="placeholder">
        </div>
        <div class="form-group">
          <label for="">Password</label>
          <input type="password" name="password" class="form-control" id="placeholder">
        </div>
        <div class="form-group">
          <label for="">Confirm password</label>
          <input type="password" name="password2" class="form-control" id="placeholder">
        </div>
        <p>
        Already a member? <a href="login.php">Sign in</a>
        </p>

        <button type="submit" name="submit" class="btn btn-primary">Register</button>
      </form>

<!----------------------------------------------------------------------------->
    </div>
  </div>
</div>
</body>
</html>
