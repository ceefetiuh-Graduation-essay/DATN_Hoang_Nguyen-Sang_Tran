<?php

$con=mysqli_connect('localhost','id9224847_ngochoang','01654755979','id9224847_data');

 ?>



