<?php ob_start();
session_start(); 
 
if (isset($_SESSION['username'])){
    header('Localtion:hienthi.php');
}
else{
     header('Localtion:login.php');

}

?>

<!DOCTYPE html>
<html>
<head>
	<title>Login</title>

<!--Add thẻ thư viện CSS------------------------------------------------------->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
<!--Add thẻ thư viện icon------------------------------------------------------>
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="icon" href="http://icons.iconarchive.com/icons/bokehlicia/captiva/128/rocket-icon.png" type="image/x-icon" />
	 <style>img[alt="www.000webhost.com"]{display:none;}</style>
<style>
*{
	margin: 0px;
	padding:0px;
}
body{
	font-size: 120%;
	/*background: #F8F8FF;*/
	background:#8ed7b4;
  width: 100%;
	height: 700px;

}

</style>
<!----------------------------------------------------------------------------->
</head>
<body>
<div class="container">
  <div class="row text-center">
		<a href="index.html">
			<img src="images/MAU2.png" style="width:300px;height:300px">
		</a>

    <h3>Login</h3>
  </div>
<!----------------------------------------------------------------------------->
  <div class="row">
    <div class="col-md-6 col-md-offset-3 ">
      <?php require('config.php');
			  if(isset($_POST['submit'])){
	        if(empty($_POST['username']) or empty($_POST['password']))
	        {
	            echo '<p style="color:red"> Vui lòng không để trống </p';
	        }
	        else {
	          $username=$_POST['username'];
	          $password=$_POST['password'];
	          $sql="select * from users where username='$username' and password='$password'";
	          $query=mysqli_query($con,$sql);
	          $num=mysqli_num_rows($query);
	          if($num==0)
	          {
	              echo '<p style="color:red">Username hoặc password không đúng </p';
	          }
	          else {
	            $_SESSION['username']=$username;
	            header('location:hienthi.php');
	          }
	        }
	      }
	   ?>

    </div>
  </div>
<!--THẺ TẠO BẢNG--------------------------------------------------------------->
  <div class="row">
  <div class="col-md-6 col-md-offset-3">
<!--FORM----------------------------------------------------------------------->
      <form class="" action="" method="POST" role="form">
        <div class="form-group">
          <label for="">Username</label>
          <input type="text" name="username" class="form-control" id="placeholder">
        </div>
        <div class="form-group">
          <label for="">Password</label>
          <input type="password" name="password" class="form-control" id="placeholder">
        </div>
				<p>
				Already a member? <a href="register.php">Sign up</a>
				<label><input type="checkbox" name="remember" style="margin-left:50px;"> Remember me</label>
				</p>
        <button type="submit" name="submit" class="btn btn-primary"> Login </button>
      </form>
  </div>
  </div>
</div>
<!----------------------------------------------------------------------------->
</body>
</html>
