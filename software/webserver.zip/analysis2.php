<?php
 $con=mysqli_connect('localhost','id9224847_ngochoang','01654755979','id9224847_data');
 $row='';
 $query="SELECT*FROM tbl_messages2 ORDER BY DateTime_created DESC LIMIT 0,8";
 $result=mysqli_query($con,$query);
 ?>


    <script src="//ajax.googleapis.com/ajax/libs/jquery/1.9.0/jquery.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/raphael/2.1.0/raphael-min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/morris.js/0.5.1/morris.min.js"></script>
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <style>img[alt="www.000webhost.com"]{display:none;}</style>

<!----------------------------------------------------------------------------->
<!----------------------------------------------------------------------------->
<!----------------------------------------------------------------------------->
    <script src="assets/js/jquery-1.10.2.js"></script>
      <!-- Bootstrap Js -->
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- Metis Menu Js -->
    <script src="assets/js/jquery.metisMenu.js"></script>
<!--Chart---------------------------------------------------------------------->
    <script type="text/javascript">
          google.charts.load('current', {'packages':['corechart']});
          google.charts.setOnLoadCallback(drawChart);

          function drawChart() {
            var data = google.visualization.arrayToDataTable([

                            ['Date', 'Temperature','Humidity','Soil'],
                            <?php
                            while($row = mysqli_fetch_array($result))
                            {
                                 echo "['".$row["DateTime_created"]."', ".$row["nhiet_do"].", ".$row["do_am"].", ".$row["am_dat"]."],";
                            }
                            ?>
                       ]);

            var options = {
              title: 'Analysis',
              curveType: 'function',
              legend: { position: 'bottom' }
            };

            var chart = new google.visualization.AreaChart(document.getElementById('analysis2'));

            chart.draw(data, options);
          }
        </script>


