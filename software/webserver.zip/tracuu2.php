<?php require('config.php') ?>

<?php

$rs3 = mysqli_query($con, "SELECT * FROM tbl_messages2");
$tb_nd =  0;
$tb_do = 0;
$t_nd =  0;
$t_do = 0;
$t_n = 0;
$t_d = 0;
$t_dat=0;
$t_da=0;
if(mysqli_num_rows($rs3) > 0){
//DÒNG NÀY NẾU ĐÚNG THÌ DO TÔI CODE
//CÒN NẾU SAI THÌ THẰNG NÀO CODE TÔI KHÔNG BIẾT

while($s6 = mysqli_fetch_assoc($rs3)){
$t_nd =  $t_nd + $s6['nhiet_do'];
$t_da = $t_da + $s6['do_am'];
$t_do =$t_do +$s6['am_dat'];
$t_n++;
$t_d++;
$t_dat++;
}
$tb_nd = $t_nd/$t_n; // Trung bình nhiệt độ
$tb_da = $t_da/$t_d; // Trung bình độ ẩm
$tb_do = $t_do/$t_dat; // Trung bình độ ẩm đất
//echo $tb_da;

}

?>
