 <?php

    $servername = "localhost";
    $username = "id9224847_ngochoang";
    $password = "01654755979";
    $dbname = "id9224847_data";


    // Create connection
    $con = mysqli_connect($servername, $username, $password, $dbname);
 

        // Device one
        $max_temp = $_POST['max_temp'];
       	$min_temp = $_POST['min_temp'];
       	$max_hum = $_POST['max_hum'];
       	$min_hum = $_POST['min_hum'];
       	$max_soil = $_POST['max_soil'];
       	$min_soil = $_POST['min_soil'];
        
   	    $sql = "INSERT INTO slave1_maxmin (max_temp,min_temp,max_hum,min_hum,max_soil,min_soil) VALUES ('".$max_temp."', '".$min_temp."','".$max_hum."','".$min_hum."','".$max_soil."','".$min_soil."')";
 
 if(mysqli_query($con,$sql)){
 
 echo 'Data Submit Successfully';
 
 }
 else{
 
 echo 'Try Again';
 
 }
 mysqli_close($con);
?>
