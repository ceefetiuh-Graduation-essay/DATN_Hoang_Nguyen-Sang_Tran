 <?php

    $servername = "localhost";
    $username = "id9224847_ngochoang";
    $password = "01654755979";
    $dbname = "id9224847_data";


    // Create connection
    $con = mysqli_connect($servername, $username, $password, $dbname);
 

        // Device one
        $max_temp1 = $_POST['max_temp1'];
       	$min_temp1 = $_POST['min_temp1'];
       	$max_hum1 = $_POST['max_hum1'];
       	$min_hum1 = $_POST['min_hum1'];
       	$max_soil1 = $_POST['max_soil1'];
       	$min_soil1 = $_POST['min_soil1'];
        
   	    $sql = "INSERT INTO slave2_maxmin (max_temp1,min_temp1,max_hum1,min_hum1,max_soil1,min_soil1) VALUES ('".$max_temp1."', '".$min_temp1."','".$max_hum1."','".$min_hum1."','".$max_soil1."','".$min_soil1."')";
 
 if(mysqli_query($con,$sql)){
 
 echo 'Data Submit Successfully';
 
 }
 else{
 
 echo 'Try Again';
 
 }
 mysqli_close($con);
?>
