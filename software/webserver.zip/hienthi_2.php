<?php
     $conn=mysqli_connect('localhost','id9224847_ngochoang','01654755979','id9224847_data');
     $result=mysqli_query($conn,'SELECT * FROM tbl_messages4 ORDER BY messageID DESC LIMIT 1');

     // $row = mysqli_fetch_array($result);

    
       ?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Smart Data Logger</title>
    <!-- Bootstrap Styles-->
    <link href="assets/css/bootstrap.css" rel="stylesheet" />
    <!-- FontAwesome Styles-->
    <link href="assets/css/font-awesome.css" rel="stylesheet" />
    <!-- Morris Chart Styles-->
    <link href="assets/js/morris/morris-0.4.3.min.css" rel="stylesheet" />
    <!-- Custom Styles-->
    <link href="assets/css/custom-styles.css" rel="stylesheet" />
    <!-- Google Fonts-->
    <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css' />
    <style>img[alt="www.000webhost.com"]{display:none;}</style>

</head>

<body>
<div id="wrapper">
    <nav class="navbar navbar-default top-navbar" role="navigation">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
              <a class="navbar-brand" href="index.html"><i class="fa fa-cloud-upload" style="font-size:24px; margin-left:55px;"></i><strong>  HOME </strong></a>
        </div>
<!--Logout--------------------------------------------------------------------->
      <ul class="nav navbar-top-links navbar-right">
            <li class="dropdown">
              <a class="dropdown-toggle" data-toggle="dropdown" href="#" aria-expanded="false">
                  <i class="fa fa-user fa-fw"></i> <i class="fa fa-caret-down"></i>
              </a>
              <ul class="dropdown-menu dropdown-user"  >
                  <li><a><i class="fa fa-user fa-fw"> </i> Xin chào Admin </a>
                  </li>
                  <li class="divider"></li>
                  <li><a href="logout.php"><i class="fa fa-sign-out fa-fw"></i> Đăng xuất</a>
                  </li>
              </ul>

          </li>
      </ul>
  </nav>
<!----------------------------------------------------------------------------->
        <nav class="navbar-default navbar-side" role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav" id="main-menu">

                    <li>
                        <a class="active-menu" href="#"><i class="fa fa-dashboard"></i> DEVICE TWO</a>
                    </li>
                    <li>
                          <a href="hienthi.php"><i class="fa fa-dashboard"></i> DEVICE ONE</a>
                    </li>
				           	<li>
                        <a href="chart.php"><i class="fa fa-bar-chart-o"></i> DEVICE ONE CHART</a>
                    </li>
                    <li>
                       <a href="chart2.php"><i class="fa fa-bar-chart-o"></i> DEVICE TWO CHART</a>
                   </li>
                    <li>
                        <a href="table.php"><i class="fa fa-table"></i> DEVICE ONE TABLE </a>
                    </li>
                    <li>
                        <a href="table2.php"><i class="fa fa-table"></i> DEVICE TWO TABLE</a>
                    </li>

                </ul>

            </div>

        </nav>
        <!-- /. NAV SIDE  -->
        <div id="page-wrapper">
            <div id="page-inner">


                <div class="row">
                    <div class="col-md-12">
                        <h1 class="page-header">
                            Dashboard <small>Device two present</small> 
                        </h1>

                    </div>
                </div>


		<div class="row">
        <?php
         if($row = mysqli_fetch_array($result)){
        ?>
     
			<div class="col-xs-6 col-md-3">
				<div class="panel panel-default">
					<div class="panel-body easypiechart-panel">
						<h4>Temperature</h4>
						<div class="easypiechart" id="easypiechart-blue" data-percent= <?php echo $row["nhiet_do"];?> ><span class="percent"><?php echo $row["nhiet_do"];?> &#8451; </span>
						</div>
					</div>
				</div>
			</div>
			<div class="col-xs-6 col-md-3">
				<div class="panel panel-default">
					<div class="panel-body easypiechart-panel">
						<h4>Humidity</h4>
						<div class="easypiechart" id="easypiechart-orange" data-percent=<?php echo $row["do_am"]; ?> ><span class="percent"><?php echo $row["do_am"]; ?> %</span>
						</div>
					</div>
				</div>
			</div>
			<div class="col-xs-6 col-md-3">
				<div class="panel panel-default">
					<div class="panel-body easypiechart-panel">
						<h4>Soil</h4>
						<div class="easypiechart" id="easypiechart-teal" data-percent=<?php echo $row["am_dat"]; ?>><span class="percent"><?php echo $row["am_dat"]; ?> %</span>
						</div>
					</div>
				</div>
			</div>
      <div class="col-xs-6 col-md-3">
				<div class="panel panel-default">
					<div class="panel-body easypiechart-panel">
						<h4>Pump</h4>
						<div class="easypiechart" id="easypiechart-red" data-percent='100'><span class="percent"><?php echo $row["motor"]; ?></span>
						</div>
					</div>
				</div>
			</div>
		</div>
		
		
		<div class="row" style="width=1000px;">
                    <div class="col-md-9 col-sm-12 col-xs-12">
                       <div class="panel panel-default" style="width:1010px;">
                           <div class="panel-heading">
                               DATA ANALYTICS <small>Update to <?php echo $row["DateTime_created"]; ?></small>
                           </div>
                            <?php require('tracuu2.php') ?>
                           
                           <div class="panel-body">
                               <?php require('analysis2.php') ?>
                               <div id="analysis2"style="width:970px;height:400px;" ></div> </br>
                                <h2 style="margin-left:150px;">Calculate the arithmetic mean of the values:</h2>
                               <h4 style="margin-left:150px;"> #  Average temperature:  <?php echo round($tb_nd); ?>  &#8451;</h4>
                               <h4 style="margin-left:150px;"> #  Average humidity: <?php echo round($tb_da,2); ?>%  </h4>
                               <h4 style="margin-left:150px;"> #  Average soil moisture: <?php echo round($tb_do,2); ?> %</h4>
                           </div>

                       </div>  
                        
                        
                     <!---------------------------------------------------------->   
                        
                        
                        <div class="panel panel-default" style="width:1010px;height:270px;">
                            <div class="panel-heading">
                               WEATHER
                            </div>
                            <div class="panel-body">
                                <!-- weather widget start --><div id="m-booked-weather-bl250-64493"> <div class="booked-wzs-250-175 weather-customize" style="background-color:#135091;width:430px;" id="width3"> <div class="booked-wzs-250-175_in"> <div class="booked-wzs-250-175-data"> <div class="booked-wzs-250-175-left-img wrz-18"> <a target="_blank" href="https://www.booked.net/"> <img src="//s.bookcdn.com/images/letter/logo.gif" alt="booked.net" /> </a> </div> <div class="booked-wzs-250-175-right"> <div class="booked-wzs-day-deck"> <div class="booked-wzs-day-val"> <div class="booked-wzs-day-number"><span class="plus">+</span>35</div> <div class="booked-wzs-day-dergee"> <div class="booked-wzs-day-dergee-val">&deg;</div> <div class="booked-wzs-day-dergee-name">C</div> </div> </div> <div class="booked-wzs-day"> <div class="booked-wzs-day-d">H: <span class="plus">+</span>35&deg;</div> <div class="booked-wzs-day-n">L: <span class="plus">+</span>28&deg;</div> </div> </div> <div class="booked-wzs-250-175-info"> <div class="booked-wzs-250-175-city smolest">Ho Chi Minh City </div> <div class="booked-wzs-250-175-date">Wednesday, 10 April</div> <div class="booked-wzs-left"> <span class="booked-wzs-bottom-l">See 7-Day Forecast</span> </div> </div> </div> </div> <a target="_blank" href="https://www.booked.net/weather/ho-chi-minh-city-18408"> <table cellpadding="0" cellspacing="0" class="booked-wzs-table-250"> <tr> <td>Thu</td> <td>Fri</td> <td>Sat</td> <td>Sun</td> <td>Mon</td> <td>Tue</td> </tr> <tr> <td class="week-day-ico"><div class="wrz-sml wrzs-18"></div></td> <td class="week-day-ico"><div class="wrz-sml wrzs-18"></div></td> <td class="week-day-ico"><div class="wrz-sml wrzs-03"></div></td> <td class="week-day-ico"><div class="wrz-sml wrzs-01"></div></td> <td class="week-day-ico"><div class="wrz-sml wrzs-01"></div></td> <td class="week-day-ico"><div class="wrz-sml wrzs-01"></div></td> </tr> <tr> <td class="week-day-val"><span class="plus">+</span>34&deg;</td> <td class="week-day-val"><span class="plus">+</span>33&deg;</td> <td class="week-day-val"><span class="plus">+</span>33&deg;</td> <td class="week-day-val"><span class="plus">+</span>35&deg;</td> <td class="week-day-val"><span class="plus">+</span>36&deg;</td> <td class="week-day-val"><span class="plus">+</span>36&deg;</td> </tr> <tr> <td class="week-day-val"><span class="plus">+</span>26&deg;</td> <td class="week-day-val"><span class="plus">+</span>26&deg;</td> <td class="week-day-val"><span class="plus">+</span>26&deg;</td> <td class="week-day-val"><span class="plus">+</span>24&deg;</td> <td class="week-day-val"><span class="plus">+</span>25&deg;</td> <td class="week-day-val"><span class="plus">+</span>25&deg;</td> </tr> </table> </a> </div></div> </div><script type="text/javascript"> var css_file=document.createElement("link"); css_file.setAttribute("rel","stylesheet"); css_file.setAttribute("type","text/css"); css_file.setAttribute("href",'https://s.bookcdn.com/css/w/booked-wzs-widget-275.css?v=0.0.1'); document.getElementsByTagName("head")[0].appendChild(css_file); function setWidgetData(data) { if(typeof(data) != 'undefined' && data.results.length > 0) { for(var i = 0; i < data.results.length; ++i) { var objMainBlock = document.getElementById('m-booked-weather-bl250-64493'); if(objMainBlock !== null) { var copyBlock = document.getElementById('m-bookew-weather-copy-'+data.results[i].widget_type); objMainBlock.innerHTML = data.results[i].html_code; if(copyBlock !== null) objMainBlock.appendChild(copyBlock); } } } else { alert('data=undefined||data.results is empty'); } } </script> <script type="text/javascript" charset="UTF-8" src="https://widgets.booked.net/weather/info?action=get_weather_info&ver=6&cityID=18408&type=3&scode=124&ltid=3458&domid=w209&anc_id=10330&cmetric=1&wlangID=1&color=135091&wwidth=430&header_color=ffffff&text_color=333333&link_color=08488D&border_form=1&footer_color=ffffff&footer_text_color=333333&transparent=0"></script><!-- weather widget end -->
                   </div>
                            </div>
                        </div>
                    </div>
            
                    

                </div>
    <!-------------------------------------------------------------------------->

              <?php } ?>
            </div>
            <!-- /. PAGE INNER  -->
        </div>
        <!-- /. PAGE WRAPPER  -->
    </div>
    <!-- /. WRAPPER  -->
    <!-- JS Scripts-->
    <!-- jQuery Js -->
    <script src="assets/js/jquery-1.10.2.js"></script>
    <!-- Bootstrap Js -->
    <script src="assets/js/bootstrap.min.js"></script>

    <!-- Metis Menu Js -->
    <script src="assets/js/jquery.metisMenu.js"></script>
    <!-- Morris Chart Js -->
    <script src="assets/js/morris/raphael-2.1.0.min.js"></script>
    <script src="assets/js/morris/morris.js"></script>


	<script src="assets/js/easypiechart.js"></script>
	<script src="assets/js/easypiechart-data.js"></script>


    <!-- Custom Js -->
    <script src="assets/js/custom-scripts.js"></script>
    


</body>

</html>
