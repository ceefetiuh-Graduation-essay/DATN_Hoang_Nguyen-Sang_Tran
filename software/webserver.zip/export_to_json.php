<!--Xuất dữ liệu trong DATABASE thành File JSON-------------------------------->

<?php
function get_data()
{
$connect=mysqli_connect('localhost','id9004268_thuthapdulieu','smartdatalogger','id9004268_thuthapdulieu');
  $query="SELECT*FROM tbl_messages";
  $result=mysqli_query($connect,$query);
  $data=array();
  //$data=""
  while ($row=mysqli_fetch_array($result))
  {
    //$data.="{STT:'".$row["messageID"]."',Thời gian:'".$row["DateTime_created"]."',Kênh:'".$row["topic"]."',Nhiệt độ:'".$row["nhiet_do"]."',Độ ẩm:'".$row["do_am"]."',}";
   //  echo $data;
    $data[]=array(
     'So thu tu' => $row["messageID"],
     'Thoi gian' => $row["DateTime_created"],
     'Kenh' => $row["topic"],
     'Nhiet do' => $row["nhiet_do"],
     'Do am' => $row["do_am"]
   );
  }
  return json_encode($data);
}
/*--------------------Lưu dữ liệu thành file JSON-----------------------------*/
  $file_name='dulieu.json';
  if(file_put_contents($file_name,get_data()))
  {
  echo $file_name;
  }
  else
  {
  echo "There is some error";
  }
?>
