<?php
//export.php
$connect=mysqli_connect('localhost','id9224847_ngochoang','01654755979','id9224847_data');
$output = '';
$query = "SELECT * FROM tbl_messages2 ORDER BY messageID DESC";
$result = mysqli_query($connect, $query);
 if(mysqli_num_rows($result) > 0)
 {
  $output .= '
   <table class="table" bordered="1">
   <tr>
   <th>Số thứ tự</th>
   <th>Ngày tháng</th>
   <th>Thời gian</th>
   <th>Nhiệt độ</th>
   <th>Độ ẩm</th>
   <th>Độ ẩm đất</th>
   </tr>
  ';
  while($row = mysqli_fetch_array($result))
  {
   $output .= '
    <tr>
    <td>'.$row["messageID"].'</td>
    <td>'.$row["Date"].'</td>
    <td>'.$row["Time"].'</td>
    <td>'.$row["nhiet_do"].'</td>
    <td>'.$row["do_am"].'</td>
    <td>'.$row["am_dat"].'</td>



    </tr>
   ';
  }
  $output .= '</table>';
 header('Content-Type: application/vnd.ms-excel');
 header('Content-Disposition: attachment;filename="Slave_two.xls"');
 header('Cache-Control: max-age=0');
  echo $output;
 }

?>
