package com.example.smartdataloggerv2;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;

public class Chart_twoActivity extends AppCompatActivity {
    private Button btn_nhietdo,btn_doam,btn_doamdat;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chart_one);


        btn_nhietdo=findViewById(R.id.nhiet_do);
        btn_doam=findViewById(R.id.do_am);
        btn_doamdat=findViewById(R.id.do_am_dat);


        btn_nhietdo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Chart_twoActivity.this, Temp_Slave_twoActivity.class);
                startActivity(intent);
            }
        });
        btn_doam.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Chart_twoActivity.this, Hum_Slave_twoActivity.class);
                startActivity(intent);
            }
        });
        btn_doamdat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Chart_twoActivity.this, Soild_Slave_twoActivity.class);
                startActivity(intent);
            }
        });
    }
}
