package com.example.smartdataloggerv2;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;


public class ResultLogin extends AppCompatActivity {
     private ImageView profile;
     private Button btnLogout;
     private ImageView slave_1;
     private ImageView slave_2;
     private ImageView Chart1,Chart2;
     private ImageView about;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result_login);
        // Session

        addControl();
        btnLogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                AlertDialog.Builder a = new AlertDialog.Builder(ResultLogin.this);
                a.setTitle("Notification");
                a.setIcon(R.drawable.icon);
                a.setMessage("Do you close Application ?");

                a.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                       ResultLogin.this.finish();
                    }
                });

                a.setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                });

                a.show();

                SharedPreferences sharedpreferences = getSharedPreferences(LoginActivity.MyPREFERENCES, Context.MODE_PRIVATE);
                SharedPreferences.Editor editor = sharedpreferences.edit();
                editor.clear();
                editor.commit();
            }
        });
       slave_1.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {
               Intent intent = new Intent(ResultLogin.this, Slave_oneActivity.class);
               startActivity(intent);
           }
       });
        slave_2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ResultLogin.this, Slave_twoActivity.class);
                startActivity(intent);
            }
        });
        profile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ResultLogin.this, SensorSettingActivity.class);
                startActivity(intent);
            }
        });
        Chart1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent =new Intent(ResultLogin.this,Chart_oneActivity.class);
                startActivity(intent);
            }
        });
        Chart2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent =new Intent(ResultLogin.this,Chart_twoActivity.class);
                startActivity(intent);
            }
        });
        about.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent =new Intent(ResultLogin.this,View_settingSensorActivity.class);
                startActivity(intent);
            }
        });
    }

    private void addControl() {
        profile =(ImageView) findViewById(R.id.profile);
        btnLogout=(Button)findViewById(R.id.btnLogout);
        slave_1 =(ImageView)findViewById(R.id.slave_1);
        slave_2 =(ImageView)findViewById(R.id.slave_2);
        Chart1=(ImageView)findViewById(R.id.chart1);
        Chart2=(ImageView)findViewById(R.id.chart2);
        about=(ImageView)findViewById(R.id.about);

   }
}
