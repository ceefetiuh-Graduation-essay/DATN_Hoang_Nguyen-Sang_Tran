package com.example.smartdataloggerv2;

import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class SensorSettingActivity extends AppCompatActivity {
    String ServerURL = "https://smartdataloggerspace.000webhostapp.com/mobile/setting_maxmin.php";
    String ServerURL2 = "https://smartdataloggerspace.000webhostapp.com/mobile/setting_maxmin2.php";
    EditText max_temp, min_temp, max_hum, min_hum, max_soil, min_soil;
    EditText max_temp1, min_temp1, max_hum1, min_hum1, max_soil1, min_soil1;
    Button save;
    Button save1;
    String nhietdo_max, nhietdo_min, doam_max, doam_min, doamdat_max, doamdat_min;
    String nhietdo_max1, nhietdo_min1, doam_max1, doam_min1, doamdat_max1, doamdat_min1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sensor_setting);
        // Ánh xạ các biến Edit Text Slave 1

        max_temp = (EditText) findViewById(R.id.temp_max);
        min_temp = (EditText) findViewById(R.id.temp_min);
        max_hum = (EditText) findViewById(R.id.hum_max);
        min_hum = (EditText) findViewById(R.id.hum_min);
        max_soil = (EditText) findViewById(R.id.soil_max);
        min_soil = (EditText) findViewById(R.id.soil_min);
        save = (Button) findViewById(R.id.save);
        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                GetData();

                InsertData(nhietdo_max, nhietdo_min, doam_max, doam_min, doamdat_max, doamdat_min);

            }
        });
        // Ánh xạ các biến Slave 2
        max_temp1 = (EditText) findViewById(R.id.temp_max1);
        min_temp1 = (EditText) findViewById(R.id.temp_min1);
        max_hum1 = (EditText) findViewById(R.id.hum_max1);
        min_hum1 = (EditText) findViewById(R.id.hum_min1);
        max_soil1 = (EditText) findViewById(R.id.soil_max1);
        min_soil1 = (EditText) findViewById(R.id.soil_min1);
        save1 = (Button) findViewById(R.id.save1);
        save1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                GetData2();

                InsertData2(nhietdo_max1, nhietdo_min1, doam_max1, doam_min1, doamdat_max1, doamdat_min1);

            }
        });


    }

    //----------------------------------------------------------------------------------------------
    // DEVICE ONE
    public void GetData() {
        // Set max min cho Slave 1
        nhietdo_max = max_temp.getText().toString();
        nhietdo_min = min_temp.getText().toString();
        doam_max = max_hum.getText().toString();
        doam_min = min_hum.getText().toString();
        doamdat_max = max_soil.getText().toString();
        doamdat_min = min_soil.getText().toString();

    }

    public void InsertData(final String max_temp, final String min_temp, final String max_hum, final String min_hum, final String max_soil, final String min_soil){

        class SendPostReqAsyncTask extends AsyncTask<String, Void, String> {
            @Override
            protected String doInBackground(String... params) {
                // Device one
                String temp_maxHolder = max_temp;
                String temp_minHolder = min_temp;
                String hum_maxHolder = max_hum;
                String hum_minHolder = min_hum;
                String soil_maxHolder = max_soil;
                String soil_minHolder = min_soil;

                List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();

                nameValuePairs.add(new BasicNameValuePair("max_temp", temp_maxHolder));
                nameValuePairs.add(new BasicNameValuePair("min_temp", temp_minHolder));
                nameValuePairs.add(new BasicNameValuePair("max_hum", hum_maxHolder));
                nameValuePairs.add(new BasicNameValuePair("min_hum", hum_minHolder));
                nameValuePairs.add(new BasicNameValuePair("max_soil", soil_maxHolder));
                nameValuePairs.add(new BasicNameValuePair("min_soil", soil_minHolder));
                //----------------------------------------------------------------------------------


                try {
                    HttpClient httpClient = new DefaultHttpClient();

                    HttpPost httpPost = new HttpPost(ServerURL);

                    httpPost.setEntity(new UrlEncodedFormEntity(nameValuePairs));

                    HttpResponse httpResponse = httpClient.execute(httpPost);

                    HttpEntity httpEntity = httpResponse.getEntity();


                } catch (ClientProtocolException e) {

                } catch (IOException e) {

                }
                return "Data Inserted Successfully";
            }

            @Override
            protected void onPostExecute(String result) {

                super.onPostExecute(result);

                Toast.makeText(SensorSettingActivity.this, "Save Successfully", Toast.LENGTH_LONG).show();

            }
        }

        SendPostReqAsyncTask sendPostReqAsyncTask = new SendPostReqAsyncTask();

        sendPostReqAsyncTask.execute(max_temp, min_temp, max_hum, min_hum, max_soil, min_soil);
    }
    //----------------------------------------------------------------------------------------------
    public void GetData2() {
        // Set max min cho Slave 1
        nhietdo_max1 = max_temp1.getText().toString();
        nhietdo_min1 = min_temp1.getText().toString();
        doam_max1 = max_hum1.getText().toString();
        doam_min1 = min_hum1.getText().toString();
        doamdat_max1 = max_soil1.getText().toString();
        doamdat_min1 = min_soil1.getText().toString();
    }
    public void InsertData2(final String max_temp1, final String min_temp1, final String max_hum1, final String min_hum1, final String max_soil1, final String min_soil1){

        class SendPostReqAsyncTask extends AsyncTask<String, Void, String> {
            @Override
            protected String doInBackground(String... params) {
                // Device one
                String temp_maxHolder1 = max_temp1;
                String temp_minHolder1 = min_temp1;
                String hum_maxHolder1 = max_hum1;
                String hum_minHolder1 = min_hum1;
                String soil_maxHolder1 = max_soil1;
                String soil_minHolder1 = min_soil1;

                List<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();

                nameValuePairs.add(new BasicNameValuePair("max_temp1", temp_maxHolder1));
                nameValuePairs.add(new BasicNameValuePair("min_temp1", temp_minHolder1));
                nameValuePairs.add(new BasicNameValuePair("max_hum1", hum_maxHolder1));
                nameValuePairs.add(new BasicNameValuePair("min_hum1", hum_minHolder1));
                nameValuePairs.add(new BasicNameValuePair("max_soil1", soil_maxHolder1));
                nameValuePairs.add(new BasicNameValuePair("min_soil1", soil_minHolder1));
                //----------------------------------------------------------------------------------


                try {
                    HttpClient httpClient = new DefaultHttpClient();

                    HttpPost httpPost = new HttpPost(ServerURL2);

                    httpPost.setEntity(new UrlEncodedFormEntity(nameValuePairs));

                    HttpResponse httpResponse = httpClient.execute(httpPost);

                    HttpEntity httpEntity = httpResponse.getEntity();


                } catch (ClientProtocolException e) {

                } catch (IOException e) {

                }
                return "Data Inserted Successfully";
            }

            @Override
            protected void onPostExecute(String result) {

                super.onPostExecute(result);

                Toast.makeText(SensorSettingActivity.this, "Save Successfully", Toast.LENGTH_LONG).show();

            }
        }

        SendPostReqAsyncTask sendPostReqAsyncTask = new SendPostReqAsyncTask();

        sendPostReqAsyncTask.execute(max_temp1, min_temp1, max_hum1, min_hum1, max_soil1, min_soil1);
    }

}