package com.example.smartdataloggerv2;

import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;


import android.content.DialogInterface;
import android.content.Intent;
import android.media.RingtoneManager;
import android.os.AsyncTask;
import android.os.Bundle;


import android.support.v4.app.NotificationCompat;
import android.support.v4.app.TaskStackBuilder;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;

import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;


public class Slave_twoActivity extends AppCompatActivity {

    HttpResponse httpResponse;
    Button update,exit;
    TextView nhiet_do,do_am,soild,history;
    JSONObject jsonObject=null;
    String StringHolder="";
    ProgressBar progressBar;
    public String TAG_Field1, TAG_Field2;
    // Add địa chỉ localhost
    String HttpURL="https://smartdataloggerspace.000webhostapp.com/mobile/data4.php";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_slave_two);

        //
        update=(Button)findViewById(R.id.update);
        nhiet_do=(TextView)findViewById(R.id.nhiet_do);
        do_am=(TextView)findViewById(R.id.do_am);
        progressBar = (ProgressBar)findViewById(R.id.progressBar);
        history=(TextView)findViewById(R.id.textview_history);
        exit=(Button)findViewById(R.id.exit);
        soild=(TextView)findViewById(R.id.soild);




        //Add sự kiên update
        update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                progressBar.setVisibility(View.VISIBLE);
                new  ReadJSON(Slave_twoActivity.this).execute();


            }
        });

        //Exit-->Close
        exit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Slave_twoActivity.this, ResultLogin.class);
                startActivity(intent);
            }
        });

    }
    public class ReadJSON extends AsyncTask<Void, Void, Void>
    {
        // Declaring CONTEXT.
        public Context context;


        public ReadJSON(Context context)
        {
            Time();
            this.context = context;

        }

        @Override
        protected void onPreExecute()
        {
            super.onPreExecute();
        }

        @Override
        protected Void doInBackground(Void... arg0)
        {

            HttpClient httpClient = new DefaultHttpClient();

            // Adding HttpURL to my HttpPost oject.
            HttpPost httpPost = new HttpPost(HttpURL);

            try {
                httpResponse=httpClient.execute(httpPost);
                StringHolder= EntityUtils.toString(((org.apache.http.HttpResponse) httpResponse).getEntity(),"UTF-8");



            } catch (ClientProtocolException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }

            try{
                JSONArray jsonArray = new JSONArray(StringHolder);
                for (int i=0;i<jsonArray.length();i++){
                    // Passing string holder variable to JSONArray.


                    jsonObject = jsonArray.getJSONObject(i);
                }



            } catch ( JSONException e) {
                e.printStackTrace();
            }

            catch (Exception e)
            {

                e.printStackTrace();
            }
            return null;
        }
        protected void onPostExecute(Void result)
        {
            try {

                // Adding JSOn string to textview after done loading.
                nhiet_do.setText(jsonObject.getString("nhiet_do"));
                do_am.setText(jsonObject.getString("do_am"));
                soild.setText(jsonObject.getString("am_dat"));

                /*TAG_Field1=jsonObject.getString("nhiet_do");
                TAG_Field2=jsonObject.getString("do_am");


                if (Integer.parseInt(TAG_Field1) <= 50) {

                    mNotification();
                }
                if (Integer.parseInt(TAG_Field2) < 70) {
                    mNotification();
                }

                */
            } catch (JSONException e) {

                e.printStackTrace();
            }

            //Hiding progress bar after done loading TextView.
            progressBar.setVisibility(View.GONE);

        }
    }

    private void Time (){
        //Time ***********************************************************************************
        Date date = new Date(System.currentTimeMillis());
        SimpleDateFormat dateformat = new SimpleDateFormat("hh:mm:ss - dd/MM/yyyy");
        String s = dateformat.format(date.getTime());
        history.setText(s);

    }

}