package com.example.smartdataloggerv2;


import android.content.Context;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;



public class View_settingSensorActivity extends AppCompatActivity {

    HttpResponse httpResponse;
    Button refresh,refresh1;
    TextView max_temp, min_temp, max_hum, min_hum, max_soil, min_soil;
    TextView max_temp1, min_temp1, max_hum1, min_hum1, max_soil1, min_soil1;
    JSONObject jsonObject=null;
    String StringHolder="";
    // Add địa chỉ localhost
    String HttpURL="https://smartdataloggerspace.000webhostapp.com/mobile/view_maxmin.php";
    String HttpURL2="https://smartdataloggerspace.000webhostapp.com/mobile/view_maxmin2.php";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_setting_sensor);

        //
        refresh=(Button) findViewById(R.id.refresh);

        max_temp = (TextView) findViewById(R.id.temp_max);
        min_temp = (TextView) findViewById(R.id.temp_min);
        max_hum = (TextView) findViewById(R.id.hum_max);
        min_hum = (TextView) findViewById(R.id.hum_min);
        max_soil = (TextView) findViewById(R.id.soil_max);
        min_soil = (TextView) findViewById(R.id.soil_min);

        // Ánh xạ các biến Slave 2
        refresh1=(Button) findViewById(R.id.refresh1);
        max_temp1 = (TextView) findViewById(R.id.temp_max1);
        min_temp1 = (TextView) findViewById(R.id.temp_min1);
        max_hum1 = (TextView) findViewById(R.id.hum_max1);
        min_hum1 = (TextView) findViewById(R.id.hum_min1);
        max_soil1 = (TextView) findViewById(R.id.soil_max1);
        min_soil1 = (TextView) findViewById(R.id.soil_min1);


        //Add sự kiên refresh
        refresh.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                new  ReadJSON(View_settingSensorActivity.this).execute();



            }
        });
        refresh1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                new  ReadJSON2(View_settingSensorActivity.this).execute();


            }
        });


    }
    public class ReadJSON extends AsyncTask<Void, Void, Void>
    {
        // Declaring CONTEXT.
        public Context context;


        public ReadJSON(Context context)
        {

            this.context = context;

        }

        @Override
        protected void onPreExecute()
        {
            super.onPreExecute();
        }

        @Override
        protected Void doInBackground(Void... arg0)
        {

            HttpClient httpClient = new DefaultHttpClient();

            // Adding HttpURL to my HttpPost oject.
            HttpPost httpPost = new HttpPost(HttpURL);

            try {
                httpResponse=httpClient.execute(httpPost);
                StringHolder= EntityUtils.toString(((org.apache.http.HttpResponse) httpResponse).getEntity(),"UTF-8");



            } catch (ClientProtocolException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }

            try{
                JSONArray jsonArray = new JSONArray(StringHolder);
                for (int i=0;i<jsonArray.length();i++){
                    // Passing string holder variable to JSONArray.


                    jsonObject = jsonArray.getJSONObject(i);
                }



            } catch ( JSONException e) {
                e.printStackTrace();
            }

            catch (Exception e)
            {

                e.printStackTrace();
            }
            return null;
        }
        protected void onPostExecute(Void result)
        {
            try {

                // Adding JSOn string to textview after done loading.
                max_temp.setText(jsonObject.getString("max_temp"));
                min_temp.setText(jsonObject.getString("min_temp"));
                max_hum.setText(jsonObject.getString("max_hum"));
                min_hum.setText(jsonObject.getString("min_hum"));
                max_soil.setText(jsonObject.getString("max_soil"));
                min_soil.setText(jsonObject.getString("min_soil"));

            } catch (JSONException e) {

                e.printStackTrace();
            }



        }
    }
    //----------------------------------------------------------------------------------------------
    public class ReadJSON2 extends AsyncTask<Void, Void, Void>
    {
        // Declaring CONTEXT.
        public Context context;


        public ReadJSON2(Context context)
        {

            this.context = context;

        }

        @Override
        protected void onPreExecute()
        {
            super.onPreExecute();
        }

        @Override
        protected Void doInBackground(Void... arg0)
        {

            HttpClient httpClient = new DefaultHttpClient();

            // Adding HttpURL to my HttpPost oject.
            HttpPost httpPost = new HttpPost(HttpURL2);

            try {
                httpResponse=httpClient.execute(httpPost);
                StringHolder= EntityUtils.toString(((org.apache.http.HttpResponse) httpResponse).getEntity(),"UTF-8");



            } catch (ClientProtocolException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }

            try{
                JSONArray jsonArray = new JSONArray(StringHolder);
                for (int i=0;i<jsonArray.length();i++){
                    // Passing string holder variable to JSONArray.


                    jsonObject = jsonArray.getJSONObject(i);
                }



            } catch ( JSONException e) {
                e.printStackTrace();
            }

            catch (Exception e)
            {

                e.printStackTrace();
            }
            return null;
        }
        protected void onPostExecute(Void result)
        {
            try {

                // Adding JSOn string to textview after done loading.
                max_temp1.setText(jsonObject.getString("max_temp1"));
                min_temp1.setText(jsonObject.getString("min_temp1"));
                max_hum1.setText(jsonObject.getString("max_hum1"));
                min_hum1.setText(jsonObject.getString("min_hum1"));
                max_soil1.setText(jsonObject.getString("max_soil1"));
                min_soil1.setText(jsonObject.getString("min_soil1"));


            } catch (JSONException e) {

                e.printStackTrace();
            }



        }
    }

}